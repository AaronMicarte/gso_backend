<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('deliveryreceipt', function (Blueprint $table) {
            $table->boolean('IsPartial')->default(false)->after('InspectionCompletedAt');
            $table->timestamp('FinalizedAt')->nullable()->after('IsPartial');
        });
    }

    public function down(): void
    {
        Schema::table('deliveryreceipt', function (Blueprint $table) {
            $table->dropColumn(['IsPartial', 'FinalizedAt']);
        });
    }
};
